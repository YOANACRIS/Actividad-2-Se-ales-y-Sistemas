
% -------------------------------------------------------------
% Simulación y análisis de señales con la Transformada de Fourier
% -------------------------------------------------------------

clear; close all; clc;

%% Parámetros generales
Fs = 1000;              % Frecuencia de muestreo (Hz)
T = 1/Fs;               % Periodo de muestreo
L = 1000;               % Número de muestras
t = (0:L-1)*T;          % Vector de tiempo

%% -------------------------------
% 1. Señal Senoidal
% -------------------------------
f_sin = 50;                         % Frecuencia de la señal
x1 = sin(2*pi*f_sin*t);            % Señal senoidal

% FFT
X1 = fft(x1);
P1 = abs(X1/L);
P1 = P1(1:L/2+1);
f = Fs*(0:(L/2))/L;

% Gráficas
figure;
subplot(2,1,1);
plot(t, x1); title('Señal Senoidal en el Tiempo');
xlabel('Tiempo (s)'); ylabel('Amplitud');

subplot(2,1,2);
stem(f, P1); title('FFT de Señal Senoidal');
xlabel('Frecuencia (Hz)'); ylabel('|X(f)|');

%% -------------------------------
% 2. Pulso Rectangular
% -------------------------------
x2 = zeros(size(t));
x2(400:600) = 1;   % Pulso entre 0.4s y 0.6s

X2 = fft(x2);
P2 = abs(X2/L);
P2 = P2(1:L/2+1);

figure;
subplot(2,1,1);
plot(t, x2); title('Pulso Rectangular en el Tiempo');
xlabel('Tiempo (s)'); ylabel('Amplitud');

subplot(2,1,2);
stem(f, P2); title('FFT del Pulso Rectangular');
xlabel('Frecuencia (Hz)'); ylabel('|X(f)|');

%% -------------------------------
% 3. Función Escalón
% -------------------------------
x3 = double(t >= 0.5);   % Escalón en t = 0.5s

X3 = fft(x3);
P3 = abs(X3/L);
P3 = P3(1:L/2+1);

figure;
subplot(2,1,1);
plot(t, x3); title('Función Escalón en el Tiempo');
xlabel('Tiempo (s)'); ylabel('Amplitud');

subplot(2,1,2);
stem(f, P3); title('FFT del Escalón');
xlabel('Frecuencia (Hz)'); ylabel('|X(f)|');

%% -------------------------------
% 4. Verificación de Linealidad
% -------------------------------
x_lin = 0.5*x1 + 0.5*x2;
X_lin = fft(x_lin);
P_lin = abs(X_lin/L);
P_lin = P_lin(1:L/2+1);

figure;
subplot(2,1,1);
plot(t, x_lin); title('Combinación Lineal de Señales');
xlabel('Tiempo (s)'); ylabel('Amplitud');

subplot(2,1,2);
stem(f, P_lin); title('FFT - Linealidad');
xlabel('Frecuencia (Hz)'); ylabel('|X(f)|');

%% -------------------------------
% 5. Desplazamiento en el tiempo
% -------------------------------
x1_shifted = sin(2*pi*f_sin*(t - 0.1));
X1_shifted = fft(x1_shifted);
P1_shifted = abs(X1_shifted/L);
P1_shifted = P1_shifted(1:L/2+1);

figure;
subplot(2,1,1);
plot(t, x1_shifted); title('Señal Senoidal Desplazada (0.1s)');
xlabel('Tiempo (s)'); ylabel('Amplitud');

subplot(2,1,2);
stem(f, P1_shifted); title('FFT - Desplazamiento en el Tiempo');
xlabel('Frecuencia (Hz)'); ylabel('|X(f)|');

%% -------------------------------
% 6. Escalamiento en Frecuencia
% -------------------------------
x1_scaled = sin(2*pi*(2*f_sin)*t);  % Doble frecuencia
X1_scaled = fft(x1_scaled);
P1_scaled = abs(X1_scaled/L);
P1_scaled = P1_scaled(1:L/2+1);

figure;
subplot(2,1,1);
plot(t, x1_scaled); title('Señal con Frecuencia Escalada');
xlabel('Tiempo (s)'); ylabel('Amplitud');

subplot(2,1,2);
stem(f, P1_scaled); title('FFT - Escalamiento en Frecuencia');
xlabel('Frecuencia (Hz)'); ylabel('|X(f)|');
